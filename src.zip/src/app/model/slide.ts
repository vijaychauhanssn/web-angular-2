export class Slides  {
  constructor(
    public id: number,
    public slide:number,
    public title:string,
    public name:string,
    public logo:boolean,
    public link: string
    ) { }
}