export class Eventos {
  constructor(
    public id: number,
    public name: string,
    public hour: number,
    public data:number,
    public link:string,
    public title:string,
    public sede: string
    ) { }
}