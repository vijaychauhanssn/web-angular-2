export class Youtube {
  constructor(
    public id: number,
    public image:string,
    public title:string,
    public link: string
    ) { }
}