export class Contacto {

	constructor(
    public nombre: string,
    public apellido: string,
    public submit: string,
    public text: string,
    public number: number,
    public consulta: string,
    public email: string
  ) {  }
 
}
