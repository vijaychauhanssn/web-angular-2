export class Membresia {
constructor(
    public id:    number,
    public name:  string,
    public image: string,
    public slide: string,
    public list: number,
    public title: string,
    public desde: string
    ) { }

}
