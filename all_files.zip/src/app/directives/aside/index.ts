﻿export * from './aside.directive';
