export class Hero {

  constructor(
    public id: number,
    public name: string,
    public email: string,
    public power: string,
    public alterEgo?: string
  ) {  }

}