export class Data {

	constructor(
	    public image?: string,
	    public link?: string,
	    public date?: string,
	    public text?: string,
	    public images?:string[],
	    public post?:string[],
	    public data?:string,
 
  ) { 
}

 
}




